<!--Untuk Memanggil Navbar di components/navbar.blade.php-->
<x-navbar></x-navbar>

<!--Untuk Memanggil Header di components/header.blade.php-->
<x-header>Tabel User</x-header>

<!--Untuk Memanggil Layout di components/layout.blade.php-->
<x-layout>
    Ini adalah Homepage
</x-layout>
